# Kezza Agent

Standalone Expo app for Kezza field agents. This project is separate from the existing Kezza mobile app, but it connects to the same FastAPI API and therefore the same agent, patient, referral, and commission records.

## Agent workflow

1. Sign in with an Indian mobile number and the API's OTP flow.
2. If the number is new, complete agent registration after OTP verification.
3. Add a patient lead with their name, mobile number, and optional service interest.
4. Track the lead through registered, contacted, consultation booked, converted, or closed statuses.
5. Copy or share the agent referral link.
6. Review commission earnings returned by `GET /api/v1/wallet/agent`.

## What the current backend supports

The app uses the existing `/api/v1/auth`, `/api/v1/referrals`, and `/api/v1/wallet/agent` endpoints. It does not write directly to PostgreSQL. Patient points are owned by the patient wallet. The current backend has no agent-points ledger or agent-points endpoint, so this app does not display a fabricated agent-points balance. Add that ledger, policy, and API contract on the backend before enabling agent points. See [backend integration notes](docs/backend-integration.md).

The API currently returns patient referral links using the existing `kezzamobile://` patient-app scheme. The separate agent app has its own `kezza-agent://` scheme; referrals intentionally open the patient app so a patient can complete their own signup.

## Run on macOS

Install Node.js 20 or newer. Copy `.env.example` to `.env` and set `EXPO_PUBLIC_API_URL` to the computer running FastAPI. For Expo Go on a physical phone, use the Mac's Wi-Fi/LAN IP address, not `localhost`; allow port 8000 through the Mac firewall if prompted. The API should be reachable at `http://<mac-lan-ip>:8000/health`.

From this folder:

```bash
npm install
npx expo install --fix
npm run start
```

Scan the QR code with Expo Go, or press `i` if Xcode's iOS Simulator is installed. The API's local development OTP is returned as `dev_code`; production OTP delivery must be configured on the backend.

## API and privacy notes

- `EXPO_PUBLIC_API_URL` is bundled into the client and is not a place for secrets.
- The agent must confirm that the patient agreed to have their contact details submitted before creating a lead. The current API schema has no consent field, so this client confirmation is not a server-side consent record.
- An existing account with a non-agent role is refused by the agent app.
- API permissions remain enforced by JWT checks on the server; client-side route guards only control navigation.

## Project layout

`src/app` contains Expo Router screens; `src/features` contains API types and queries; `src/lib` contains the API client and small shared utilities; `src/store` contains the isolated app session; `src/components` contains shared mobile UI.
